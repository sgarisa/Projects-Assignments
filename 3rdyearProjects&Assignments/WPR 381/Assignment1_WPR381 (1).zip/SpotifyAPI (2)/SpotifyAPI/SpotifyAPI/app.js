require('dotenv').config(); // Load environment variables from .env file
const axios = require('axios'); // HTTP client for making requests
const fileStream = require('fs'); // Filesystem module for writing to files

const clientId = process.env.SPOTIFY_CLIENT_ID;
const clientSecret = process.env.SPOTIFY_CLIENT_SECRET;

// install npm install readline-sync

var line = require('readline-sync');
var searchRequest = line.question('Please type the name of the song you want to search for:');

// Function to get the access token
const getAccessToken = async () => {
  const response = await axios.post('https://accounts.spotify.com/api/token', 'grant_type=client_credentials', {
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded',
      'Authorization': 'Basic ' + Buffer.from(clientId + ':' + clientSecret).toString('base64'),
    },
  });
  return response.data.access_token;
};

// Function to search for a track and save results to a JSON file
const searchTrack = async (trackName) => {
  try {
    const accessToken = await getAccessToken();
    const searchResult = await axios.get('https://api.spotify.com/v1/search', {
      headers: {
        'Authorization': `Bearer ${accessToken}`,
      },
      params: {
        q: trackName,
        type: 'track',
        limit: 1,
      },
    });

    const song = searchResult.data.tracks.items[0];
    if (song) {
      const { songName, artists, preview_url, album } = song;
      const trackDetails = {
        song: songName,
        artists: artists.map(artist => artist.name),
        preview_link: preview_url,
        album: album.name,
      };
      
      // Write track details to a JSON file
      fileStream.writeFileSync('trackDetails.json', JSON.stringify(trackDetails, null, 2), 'utf-8');

      // write a response for the user 
      console.log(`The searched song ${searchRequest} by ${ artists.map(artist => artist.name).join(', ')} was successfully saved to the trackDetails.json file`);
    } else {
      console.log('No songs matching that tile were found in the database.');
    }
  } catch (error) {
    console.err('An error occured:', error);
  }
};

// searches for the song depending on user input
searchTrack(searchRequest);
