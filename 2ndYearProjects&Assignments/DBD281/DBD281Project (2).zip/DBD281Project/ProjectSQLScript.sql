USE PineWoodDB

/*CREATE TABLE Student

( StudentID INT PRIMARY KEY IDENTITY(1,1) ,
 FirstName VARCHAR(30) , 
 LastName VARCHAR(30) ,
 Gender CHAR(1) , --Choose Male (M) or Female (F)
 DateOfBirth DATETIME ,
 ResidentialAddress VARCHAR(50)
 
)

CREATE TABLE Teacher 
( TeacherID INT PRIMARY KEY IDENTITY (1,1) ,
  FirstName VARCHAR(30) ,
  LastName VARCHAR(30),
  DateOfBirth DATETIME 

)

CREATE TABLE StudentTeacher 
(  StudentID  INT FOREIGN KEY REFERENCES Student(StudentID) ,
    TeacherID INT  FOREIGN KEY REFERENCES  Teacher(TeacherID) ,
     Divison CHAR(1) ,
	 PRIMARY KEY (StudentID , TeacherID)
)

CREATE TABLE Parent
( ParentID INT PRIMARY KEY IDENTITY(1,1) ,
FirstName VARCHAR(30),
LastName VARCHAR(30),
CellNumber INT,
EmailAddress VARCHAR(30)
)

CREATE TABLE StudentParent
( StudentID INT FOREIGN KEY REFERENCES Student(StudentID),
ParentID INT FOREIGN KEY REFERENCES Parent(ParentID),
ChildID INT
PRIMARY KEY (StudentID, ParentID)
)

CREATE TABLE Class
(ClassID INT PRIMARY KEY IDENTITY(1,1),
Name VARCHAR(30),
)

CREATE TABLE StudentClass
(StudentID INT FOREIGN KEY REFERENCES Student(StudentID),
ClassID INT FOREIGN KEY REFERENCES Class(ClassID),
ClassCode INT
PRIMARY KEY (StudentID, ClassID)
)

CREATE TABLE Schedule
(ScheduleID INT PRIMARY KEY IDENTITY(1,1),
Day DATE,
StartTime DATETIME,
EndTime DATETIME,
)

CREATE TABLE Subject
(SubjectID INT PRIMARY KEY IDENTITY(1,1),
Code INT,
RegName VARCHAR(30),
Duration VARCHAR(30),
DepartmentCode INT,
DepartmentName VARCHAR(30),
)

CREATE TABLE StudentSubject
(StudentID INT FOREIGN KEY REFERENCES Student(StudentID),
SubjectID INT FOREIGN KEY REFERENCES Subject(SubjectID),
Mark INT,
PRIMARY KEY (StudentID, SubjectID)
)

CREATE TABLE Department
(DepartmentID INT PRIMARY KEY IDENTITY(1,1),
DepartmentCode INT,
DepartmentName VARCHAR(30),
)

CREATE TABLE SubjectTeacher
(SubjectID INT FOREIGN KEY REFERENCES Subject(SubjectID),
TeacherID INT FOREIGN KEY REFERENCES Teacher(TeacherID),
SubjectCode VARCHAR(10),
PRIMARY KEY (SubjectID, TeacherID)
)

CREATE TABLE Account
(AccountID INT PRIMARY KEY IDENTITY(1,1),
AccountNo INT,
AccountName VARCHAR(30),
)

CREATE TABLE Staff
(StaffID INT PRIMARY KEY IDENTITY(1,1),
FirstName VARCHAR(30),
LastName VARCHAR(30),
JobTitle VARCHAR(20),
Gender CHAR(1) , --Choose Male (M) or Female (F)
DateOfBirth DATETIME,
PhoneNumber INT,
Address VARCHAR(20),
)*/
--Student Insertion
/*INSERT INTO Student ( FirstName , LastName , Gender , DateOfBirth , ResidentialAddress) VALUES 
( 'Liam' , 'Payne' , 'M' , '2002-03-24' , 'SavanaHills')

INSERT INTO Student ( FirstName , LastName , Gender , DateOfBirth , ResidentialAddress) VALUES 
( 'Ethan' , 'Smith' , 'M' , '2003-04-12' , 'Hekpoort')

INSERT INTO Student ( FirstName , LastName , Gender , DateOfBirth , ResidentialAddress) VALUES 
( 'Sara' , 'Delport' , 'F' , '2000-12-29' , 'Impumello')

INSERT INTO Student ( FirstName , LastName , Gender , DateOfBirth , ResidentialAddress) VALUES 
( 'Wian' , 'Steenkamp' , 'M' , '2001-03-14' , 'Diepsloot')

INSERT INTO Student ( FirstName , LastName , Gender , DateOfBirth , ResidentialAddress) VALUES 
( 'Ashley' , 'Boysen' , 'M' , 2006-12-04 , 'Dinwiddie')


--Schedule--
INSERT INTO Schedule (  StartTime, EndTime) VALUES 
( '10:00', '12:00')

INSERT INTO Schedule (  StartTime, EndTime) VALUES 
( '14:00', '17:00')

INSERT INTO Schedule (  StartTime, EndTime) VALUES 
( '9:00', '12:00')

INSERT INTO Schedule (  StartTime, EndTime) VALUES 
( '8:00', '12:00')

INSERT INTO Schedule (  StartTime, EndTime) VALUES 
( '13:00', '17:00')

--Subject--
INSERT INTO Subject ( Code, RegName, Duration, DepartmentCode, DepartmentName) VALUES 
(1 , 'Mathematics', '3 weeks', 1, 'Math')

INSERT INTO Subject ( Code, RegName, Duration, DepartmentCode, DepartmentName) VALUES 
(2 , 'Linear Programming', '2 weeks', 2, 'Linear')

INSERT INTO Subject ( Code, RegName, Duration, DepartmentCode, DepartmentName) VALUES 
(3 , 'Programming', '4 weeks', 3, 'Prog')

INSERT INTO Subject ( Code, RegName, Duration, DepartmentCode, DepartmentName) VALUES 
(4 , 'Statistics', '2 weeks', 4, 'Stats')

INSERT INTO Subject ( Code, RegName, Duration, DepartmentCode, DepartmentName) VALUES 
(5 , 'Data Warehousing', '3 weeks', 5, 'Warehousing')

--Teacher--
INSERT INTO Teacher ( FirstName, LastName, DateOfBirth) VALUES 
('Magda', 'Merwe', '1995-02-04')

INSERT INTO Teacher ( FirstName, LastName, DateOfBirth) VALUES 
('Sophie', 'De Beer', '1998-02-12')

INSERT INTO Teacher ( FirstName, LastName, DateOfBirth) VALUES 
('Johan', 'Reddy', '1985-09-29')

INSERT INTO Teacher ( FirstName, LastName, DateOfBirth) VALUES 
('Gift', 'Steenkamp', '1999-02-11')

INSERT INTO Teacher ( FirstName, LastName, DateOfBirth) VALUES 
('Raymond', 'Erasmus', '2000-12-04')

--Parent--
INSERT INTO Parent ( FirstName, LastName, CellNumber, EmailAddress) VALUES 
('Jenna', 'Erasmus', 0720469228, '@jenna.petfa')

INSERT INTO Parent ( FirstName, LastName, CellNumber, EmailAddress) VALUES 
('Tobi', 'Lombie', 0790469451, '@tobi.tjabf')

INSERT INTO Parent ( FirstName, LastName, CellNumber, EmailAddress) VALUES 
('Harry', 'Viljoen', 0830469987, '@harry.kjg')

INSERT INTO Parent ( FirstName, LastName, CellNumber, EmailAddress) VALUES 
('JJ', 'Aucamp', 0840469124, '@jj.sendta')

INSERT INTO Parent ( FirstName, LastName, CellNumber, EmailAddress) VALUES 
('Simon', 'Smith', 0860469567, '@simon.kgtfa')

--staff

INSERT INTO Staff ( FirstName, LastName, JobTitle , Gender , DateOfBirth , PhoneNumber , Address) VALUES 
('Clifford', 'Brown', 'Gardner' , 'M' , '1970/03/03' , 0749568513 , '9thStreetOliveExt10')

INSERT INTO Staff ( FirstName, LastName, JobTitle , Gender , DateOfBirth , PhoneNumber , Address) VALUES 
('Faith', 'Ellie', 'Cleaner' , 'F' , '1990/04/21' , 0845772101 , '8thStreetTemExt10')

INSERT INTO Staff ( FirstName, LastName, JobTitle , Gender , DateOfBirth , PhoneNumber , Address) VALUES 
('Mary', 'Jane', 'Cleaner' , 'F' , '1980/06/13' , 0637568513 , '11thStreetTemExt5')

INSERT INTO Staff ( FirstName, LastName, JobTitle , Gender , DateOfBirth , PhoneNumber , Address) VALUES 
('Gary', 'Hope', 'Securityguard' , 'M' , '1975/05/25' , 0858869523 , '9thStreetOliveExt10')

INSERT INTO Staff ( FirstName, LastName, JobTitle , Gender , DateOfBirth , PhoneNumber , Address) VALUES 
('Charles', 'Lee', 'Securityguard' , 'M' , '1990/06/21' , 0845918204 , '8thStreetBurgerRoad')

INSERT INTO Staff ( FirstName, LastName, JobTitle , Gender , DateOfBirth , PhoneNumber , Address) VALUES 
('Richard', 'Johnson ', 'Securityguard' , 'M' , '1976/11/11' , 0866674793 , '5thStreetTembExt25')

--Department

INSERT INTO Department ( DepartmentCode , DepartmentName) VALUES (1 , 'Mathematics')
INSERT INTO Department ( DepartmentCode , DepartmentName) VALUES (2 , 'LinearProgramming')
INSERT INTO Department ( DepartmentCode , DepartmentName) VALUES (3 , 'Programming')
INSERT INTO Department ( DepartmentCode , DepartmentName) VALUES (4 , 'Stats')
INSERT INTO Department ( DepartmentCode , DepartmentName) VALUES (5 , 'Database_Warehousing')

-- Account 

INSERT INTO Account (AccountNo , AccountName)  VALUES (2316754432 , 'JJOlatunji')
INSERT INTO Account (AccountNo , AccountName)  VALUES (1990204902 , 'Simon')
INSERT INTO Account (AccountNo , AccountName)  VALUES (1445067920 , 'Tobi')
INSERT INTO Account (AccountNo , AccountName)  VALUES (1223878492 , 'HarryViljoen')
INSERT INTO Account (AccountNo , AccountName)  VALUES (9110546784 , 'Jenna')

--Class 

INSERT INTO Class (Name) VALUES ('Zeta')
INSERT INTO Class (Name) VALUES ('Gamma')
INSERT INTO Class (Name) VALUES ('Omikron')
INSERT INTO Class (Name) VALUES ('Geta')
INSERT INTO Class (Name) VALUES ('Iota')

--StudentClass

INSERT INTO StudentClass (StudentID , ClassID) VALUES (1 , 2)
INSERT INTO StudentClass (StudentID , ClassID) VALUES (2 , 1)
INSERT INTO StudentClass (StudentID , ClassID) VALUES (3 , 4)
INSERT INTO StudentClass (StudentID , ClassID) VALUES (4 , 5)
INSERT INTO StudentClass (StudentID , ClassID) VALUES (5 , 3)

--StudentParent

INSERT INTO StudentParent (StudentID , ParentID) VALUES ( 1,2)
INSERT INTO StudentParent (StudentID , ParentID) VALUES ( 2,3)
INSERT INTO StudentParent (StudentID , ParentID) VALUES ( 3,4)
INSERT INTO StudentParent (StudentID , ParentID) VALUES ( 4,5)
INSERT INTO StudentParent (StudentID , ParentID) VALUES ( 5,1)

--StudentSubject

DELETE FROM StudentSubject WHERE StudentID = 1
DELETE FROM StudentSubject WHERE StudentID = 2
DELETE FROM StudentSubject WHERE StudentID = 3
DELETE FROM StudentSubject WHERE StudentID = 4
DELETE FROM StudentSubject WHERE StudentID = 5

INSERT INTO StudentSubject (StudentID , SubjectID , Mark) VALUES ( 1 , 2 , 70)
INSERT INTO StudentSubject (StudentID , SubjectID , Mark) VALUES ( 1 , 3 , 56)
INSERT INTO StudentSubject (StudentID , SubjectID , Mark) VALUES ( 1 , 5 , 98)
INSERT INTO StudentSubject (StudentID , SubjectID , Mark) VALUES ( 1 , 4 , 95)
INSERT INTO StudentSubject (StudentID , SubjectID , Mark) VALUES ( 2 , 2 , 80)
INSERT INTO StudentSubject (StudentID , SubjectID , Mark) VALUES ( 2 , 5 , 78)
INSERT INTO StudentSubject (StudentID , SubjectID , Mark) VALUES ( 2 , 6 , 54)
INSERT INTO StudentSubject (StudentID , SubjectID , Mark) VALUES ( 3 , 2 , 66)
INSERT INTO StudentSubject (StudentID , SubjectID , Mark) VALUES ( 3 , 3 , 70)
INSERT INTO StudentSubject (StudentID , SubjectID , Mark) VALUES ( 3 , 4 , 75)
INSERT INTO StudentSubject (StudentID , SubjectID , Mark) VALUES ( 3 , 5 , 76)
INSERT INTO StudentSubject (StudentID , SubjectID , Mark) VALUES ( 3 , 6 , 82)
INSERT INTO StudentSubject (StudentID , SubjectID , Mark) VALUES ( 4 , 2 , 67)
INSERT INTO StudentSubject (StudentID , SubjectID , Mark) VALUES ( 4 , 3 , 55)
INSERT INTO StudentSubject (StudentID , SubjectID , Mark ) VALUES ( 5 , 2 , 76)
INSERT INTO StudentSubject (StudentID , SubjectID , Mark) VALUES ( 5 , 3 , 75)
INSERT INTO StudentSubject (StudentID , SubjectID , Mark) VALUES ( 5 , 4 , 74)
INSERT INTO StudentSubject (StudentID , SubjectID , Mark) VALUES ( 5 , 5 , 70)
INSERT INTO StudentSubject (StudentID , SubjectID , Mark) VALUES ( 5 , 6 , 77)

--StudentTeacher 

INSERT INTO StudentTeacher (StudentID , TeacherID , Divison) VALUES ( 1, 4 , 'A')
INSERT INTO StudentTeacher (StudentID , TeacherID , Divison) VALUES ( 1, 3 , 'A')
INSERT INTO StudentTeacher (StudentID , TeacherID , Divison) VALUES ( 1, 2 , 'B')
INSERT INTO StudentTeacher (StudentID , TeacherID , Divison) VALUES ( 1, 1 , 'A')

INSERT INTO StudentTeacher (StudentID , TeacherID , Divison) VALUES ( 2, 5 , 'A')
INSERT INTO StudentTeacher (StudentID , TeacherID , Divison) VALUES ( 2, 4 , 'C')
INSERT INTO StudentTeacher (StudentID , TeacherID , Divison) VALUES ( 2, 2 , 'B')

INSERT INTO StudentTeacher (StudentID , TeacherID , Divison) VALUES ( 3, 1 , 'A')
INSERT INTO StudentTeacher (StudentID , TeacherID , Divison) VALUES ( 3, 4 , 'D')
INSERT INTO StudentTeacher (StudentID , TeacherID , Divison) VALUES ( 3, 3 , 'B')
INSERT INTO StudentTeacher (StudentID , TeacherID , Divison) VALUES ( 3, 2 , 'C')
INSERT INTO StudentTeacher (StudentID , TeacherID , Divison) VALUES ( 3, 5 , 'A')

INSERT INTO StudentTeacher (StudentID , TeacherID , Divison) VALUES ( 4, 5 , 'D')
INSERT INTO StudentTeacher (StudentID , TeacherID , Divison) VALUES ( 4, 4 , 'C')

INSERT INTO StudentTeacher (StudentID , TeacherID , Divison) VALUES ( 5, 1 , 'A')
INSERT INTO StudentTeacher (StudentID , TeacherID , Divison) VALUES ( 5, 2 , 'A')
INSERT INTO StudentTeacher (StudentID , TeacherID , Divison) VALUES ( 5, 3 , 'B')
INSERT INTO StudentTeacher (StudentID , TeacherID , Divison) VALUES ( 5, 4 , 'C')
INSERT INTO StudentTeacher (StudentID , TeacherID , Divison) VALUES ( 5, 5 , 'D')*/

-- View Q1
/*GO
CREATE VIEW vStudentInfo (StudentID , SubjectID , Student_FirstName ,   Mark )
AS
SELECT StudentSubject.StudentID , StudentSubject.SubjectID , Student.FirstName ,  StudentSubject.Mark 
FROM StudentSubject INNER JOIN Student ON
StudentSubject.StudentID = Student.StudentID*/

/*GO

SELECT *
FROM [dbo].[vStudentInfo]*/

--View Q2 
/*GO
CREATE VIEW vStudentGender ( StudentID , TeacherID , Divison , Gender )
AS
SELECT StudentTeacher.StudentID , StudentTeacher.TeacherID , StudentTeacher.Divison , Student.Gender
FROM StudentTeacher INNER JOIN Student
ON StudentTeacher.StudentID = Student.StudentID
WHERE Student.Gender LIKE 'M'*/

/*GO
SELECT * 
FROM [dbo].[vStudentGender]*/

--Triggers Q1
/*GO
CREATE TRIGGER trInsertStudent
ON Student
FOR INSERT
AS
BEGIN 
SELECT *
FROM INSERTED
END*/

/*INSERT INTO Student (FirstName , LastName) Values ('Jason' , 'Cundy')*/

--Triggers Q2
/*GO
CREATE TRIGGER trInsertStaff
ON Staff
FOR INSERT
AS
 BEGIN 
     Print 'You cannot insert a record into staff table '
	 ROLLBACK 
 END*/

 --INSERT INTO STAFF ( FirstName , LastName , JobTitle) VALUES ('Henry' , 'Edwards' , 'Cleaner')

 -- Procedures Q1
/* GO
 CREATE PROCEDURE spAddTeacherName 
 AS
 BEGIN
 DECLARE @TeacherFname varchar(30) , @TeacherLname varchar(30) 

 IF EXISTS (SELECT * FROM Teacher WHERE FirstName = @TeacherFname )
 PRINT 'Teacher name already exists'

 ELSE
      BEGIN 
	  INSERT INTO Teacher (FirstName , LastName)
	  VALUES (@TeacherFname  , @TeacherLname )
	  END 
 END*/

 /*GO
 EXECUTE spAddTeacherName*/

 -- Create Logins 

 /*CREATE LOGIN Hrudhay 
 WITH PASSWORD = 'Garisa@123'

 CREATE LOGIN Triakshan 
 WITH PASSWORD = 'BEERUS'

 CREATE LOGIN Armandre 
 WITH PASSWORD  = '123@2023'*/

 -- Full backup of PineWood Database

 /*DECLARE @bkName VARCHAR(50) ;
 SET @bkName = 'Full Backup of Pinewood database' + CONVERT (VARCHAR(12) , GETDATE())
 BACKUP  DATABASE PineWoodDB 
 TO DISK = 'C:\PinewoodDatabase\PinewoodBackup.bak'
 WITH FORMAT , 
 NAME = @bkName*/

 --Differental Backup 
 /*BACKUP DATABASE PineWoodDB 
 TO DISK = 'C:\PinewoodDatabase\PinewoodBackup.bak'
 WITH DIFFERENTIAL ;*/















