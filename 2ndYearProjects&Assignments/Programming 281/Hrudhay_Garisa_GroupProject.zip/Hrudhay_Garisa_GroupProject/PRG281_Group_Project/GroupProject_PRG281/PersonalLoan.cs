﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GroupProject_PRG281
{
    // Public PersonalLoan, derived from the Loan class
    public class PersonalLoan : Loan
    {
        // Prime interest rate used to store the entered prime interest rate
        decimal primeInterestRate;

        public PersonalLoan(string loanNr, int loanTerm, string custLastName, string custFirstName, decimal loanAmount, decimal primeInterestRate) : base(loanNr, loanTerm, custLastName, custFirstName, loanAmount)
        {
            this.primeInterestRate = primeInterestRate;

            // Conversion of the prime interest rate to the personal interest rate
            InterestRate = primeInterestRate + 2;
        }

        // Getter and setter for the prime interest rate
        public decimal PrimeInterestRate { get => primeInterestRate; set => primeInterestRate = value; }
    }
}
