﻿using PRG282__Project__Group_6_.DataAccess;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PRG282__Project__Group_6_.Presentation
{
    public partial class Modules : Form
    {
        public Modules()
        {
            InitializeComponent();
        }

        DataHandler dhandler = new DataHandler();
        BindingSource src = new BindingSource();

        private void Modules_Load(object sender, EventArgs e)
        {
            src.DataSource = dhandler.fetchModuleData();
            dgvModule.DataSource = src;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            StudentData studentData = new StudentData();
            studentData.Show();
            this.Hide();
        }

        private void btnRead_Click(object sender, EventArgs e)
        {
            try
            {
                dgvModule.DataSource = dhandler.fetchModuleData();
            }
            catch (Exception er)
            {
                MessageBox.Show(er.Message);
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                dgvModule.DataSource = dhandler.searchModule(numericUpDown2.Value);
            }
            catch (Exception er)
            {
                MessageBox.Show(er.Message);
            }
        }

        private void btnAddModule_Click(object sender, EventArgs e)
        {
            try
            {
                dgvModule.DataSource = null;

                dhandler.insertModule(txtModuleName.Text, txtDescription.Text, txtLink.Text);

                dgvModule.DataSource = dhandler.fetchModuleData();
            }
            catch (Exception er)
            {
                MessageBox.Show(er.Message);
            }

     
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                dgvModule.DataSource = null;

                dhandler.deleteModule(numericUpDown3.Value);

                dgvModule.DataSource = dhandler.fetchModuleData();

                MessageBox.Show($"Module {numericUpDown3.Value} was removed");
            }
            catch (Exception er)
            {
                MessageBox.Show(er.Message);
            }
        }

        private void btnPrevious_Click(object sender, EventArgs e)
        {
            dgvModule.DataSource = src;
            src.MovePrevious();
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            dgvModule.DataSource = src;
            src.MoveNext();
        }

        private void btnUpdateModule_Click(object sender, EventArgs e)
        {
            try
            {
                dgvModule.DataSource = null;

                dhandler.updateModule(numericUpDown1.Value, txtModuleName.Text, txtDescription.Text, txtLink.Text);

                dgvModule.DataSource = dhandler.fetchModuleData();

                MessageBox.Show($"Details for {txtModuleName.Text} were updated");
            }
            catch (Exception er)
            {
                MessageBox.Show(er.Message);
            }    
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            frmLogin login = new frmLogin();
            login.Show();
            this.Hide();
        }

        int rowIndex = 0;
        private void dgvModule_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            rowIndex = e.RowIndex;

            DataGridViewRow row = dgvModule.Rows[rowIndex];
            numericUpDown1.Value = decimal.Parse(row.Cells[0].Value.ToString());
            txtModuleName.Text = row.Cells[1].Value.ToString();
            txtDescription.Text = row.Cells[2].Value.ToString();
            txtLink.Text = row.Cells[3].Value.ToString();
        }
    }
}
