﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PRG282__Project__Group_6_.Presentation;
using PRG282__Project__Group_6_.DataLayer;

namespace PRG282__Project__Group_6_
{
    public partial class frmLogin : Form
    {
        public frmLogin()
        {
            InitializeComponent();
         
        }

        FileHandler fhandler = new FileHandler();

        private void btnLogin_Click(object sender, EventArgs e)
        {
            if (fhandler.readFromFile(txtUsername.Text, txtPassword.Text))
            {
                MessageBox.Show($"Welcome back to the app, {txtUsername.Text}");

                StudentData stud = new StudentData();
                stud.Show();

                this.Hide();
            }
            else
            {
                MessageBox.Show("Username or password is incorrect. If you are a new user, register instead");
            }
        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            if (fhandler.readFromFile(txtUsername.Text, txtPassword.Text))
            {
                MessageBox.Show($"{txtUsername.Text} already exists as a user. Try logging in instead");
            }
            else
            {
                fhandler.writeToFile(txtUsername.Text, txtPassword.Text);
                MessageBox.Show($"Welcome to the app, {txtUsername.Text}. You are now a registered user");

                StudentData stud = new StudentData();
                stud.Show();

                this.Hide();
            }
        }

        private void frmLogin_FormClosed(object sender, FormClosedEventArgs e)
        {
            Environment.Exit(0);
        }

        private void lblShow_MouseDown(object sender, MouseEventArgs e)
        {
            txtPassword.PasswordChar = '\0';
        }

        private void lblShow_MouseUp(object sender, MouseEventArgs e)
        {
            txtPassword.PasswordChar = '*';
        }
    }
}
