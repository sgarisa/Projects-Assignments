﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing.Imaging;
using PRG282__Project__Group_6_.DataLayer;
using PRG282__Project__Group_6_.DataAccess;
using System.Data.SqlClient;

namespace PRG282__Project__Group_6_.Presentation
{
    public partial class StudentData : Form
    {
        public StudentData()
        {
            InitializeComponent();
        }

        DataHandler dhandler = new DataHandler();
        BindingSource src = new BindingSource();

        private void button6_Click(object sender, EventArgs e)
        {
            dgvStudent.DataSource = src;
            src.MovePrevious();
        }

        private void btnReload_Click(object sender, EventArgs e)
        {
            dgvStudent.DataSource = dhandler.fetchStudentData();
        }


        private void button2_Click(object sender, EventArgs e)
        {
            frmLogin log = new frmLogin();
            log.Show();
            this.Hide();
        }

        private void StudentData_Load(object sender, EventArgs e)
        {
            imgStudent.Load(@"anonymous icon 1.png");
            src.DataSource = dhandler.fetchStudentData();
            dgvStudent.DataSource = src;

            lblNote.Text = "Module Codes:\n2: Information Systems\n3: Software Testing\n4: Mathematics\n5: Statistics\n6: Programming";
            
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                dgvStudent.DataSource = dhandler.searchStudent(numericUpDown1.Value);
            }
            catch (Exception er)
            {
                MessageBox.Show(er.Message);
            }
        }

        string photo;

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                OpenFileDialog openFileDialog = new OpenFileDialog();
                openFileDialog.Filter = "Choose Image(*.jpg;*.png;*.gif;*jpeg)|*.jpg;*.png;*.gif;*jpeg";

                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    imgStudent.Image = Image.FromFile(openFileDialog.FileName);
                    photo = openFileDialog.FileName;
                }
            }
            catch (Exception er)
            {
                MessageBox.Show(er.Message);
            }
        }

        private void btnCreate_Click(object sender, EventArgs e)
        {
            try
            {
                string gender = "";

                if (rbtMale.Checked)
                {
                    gender = "Male";
                }
                else if (rbtFemale.Checked)
                {
                    gender = "Female";
                }

                dgvStudent.DataSource = null;

                dhandler.insertStudent(txtFirstName.Text, txtSurname.Text, photo, dtpDOB.Value, gender, txtPhone.Text, txtAddress.Text);

                dgvStudent.DataSource = dhandler.fetchStudentData();
            }
            catch (Exception er)
            {
                MessageBox.Show(er.Message);
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                string gender = "";

                if (rbtMale.Checked)
                {
                    gender = "Male";
                }
                else if (rbtFemale.Checked)
                {
                    gender = "Female";
                }

                dgvStudent.DataSource = null;

                dhandler.updateStudent(int.Parse(txtStudNum.Text), txtFirstName.Text, txtSurname.Text, photo, dtpDOB.Value, gender, txtPhone.Text, txtAddress.Text);

                dgvStudent.DataSource = dhandler.fetchStudentData();

                MessageBox.Show($"Details for {txtFirstName.Text} were updated");
            }
            catch (Exception er)
            {
                MessageBox.Show(er.Message);
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            { 
            dgvStudent.DataSource = null;

            dhandler.deleteStudent(numericUpDown2.Value);

            dgvStudent.DataSource = dhandler.fetchStudentData();

            MessageBox.Show($"Student {numericUpDown2.Value} was removed");
            }
            catch (Exception er)
            {
                MessageBox.Show(er.Message);
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
        }

        int rowIndex = 0;

        private void dgvStudent_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            rowIndex = e.RowIndex;

            DataGridViewRow row = dgvStudent.Rows[rowIndex];
            txtStudNum.Text = row.Cells[0].Value.ToString();
            txtFirstName.Text = row.Cells[1].Value.ToString();
            txtSurname.Text = row.Cells[2].Value.ToString();
            imgStudent.Load(row.Cells[3].Value.ToString());
            dtpDOB.Value = DateTime.Parse(row.Cells[4].Value.ToString());
            if (row.Cells[5].Value.ToString() == "Male")
            {
                rbtMale.Checked = true;
            }
            else if (row.Cells[5].Value.ToString() == "Female")
            {
                rbtFemale.Checked = true;
            }
            txtPhone.Text = row.Cells[6].Value.ToString();
            txtAddress.Text = row.Cells[7].Value.ToString();
            //txtModules.Text = row.Cells[8].Value.ToString();

        }

        private void button4_Click(object sender, EventArgs e)
        {
            dgvStudent.DataSource = src;

            src.MoveFirst();
        }

        private void btnLast_Click(object sender, EventArgs e)
        {
            dgvStudent.DataSource = src;

            src.MoveLast();
        }

        private void btnModulePage_Click(object sender, EventArgs e)
        {
            Modules mod = new Modules();
            mod.Show();
            this.Hide();
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            dgvStudent.DataSource = src;

            src.MoveNext();
        }
    }
}
