﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PRG282__Project__Group_6_.Presentation
{
    internal class Student
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Surname { get; set; }

        public string ProfilePhoto { get; set; }
        [NotMapped]
        public Image Picture
        {
            get
            {
                if (!string.IsNullOrEmpty(ProfilePhoto))
                {
                    if (File.Exists(ProfilePhoto))
                        return Image.FromFile(ProfilePhoto);
                }
                return null;
            }
        }

        public string DOB { get; set; }
        public string Gender { get; set; }
        public string Phone { get; set; }
        public string Address { get; set; }

        public Student() { }

        public Student(int id, string name, string surname, string pp, string dOB, string gender, string phone, string address)
        {
            Id = id;
            Name = name;
            Surname = surname;
            ProfilePhoto = pp;
            DOB = dOB;
            Gender = gender;
            Phone = phone;
            Address = address;
        }
    }
}
