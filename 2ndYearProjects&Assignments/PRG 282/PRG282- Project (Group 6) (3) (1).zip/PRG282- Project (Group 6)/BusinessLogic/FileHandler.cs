﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace PRG282__Project__Group_6_.DataLayer
{
    internal class FileHandler
    {
        //perform text handling on 'passwords' text file
        string path = "LoginInfo.txt";

        public Boolean readFromFile(string username, string password)
        {
            //read data from text file to compare to login entry
            string line = username + " " + password;
            Boolean result = false;

            using (StreamReader reader = new StreamReader(path))
            {
                string txt;

                while ((txt = reader.ReadLine()) != null)
                {
                    if (line == txt)
                    {
                         result = true;
                    }
                }
                 reader.Close();
            } 

            return result;
        }

        public void writeToFile(string username, string password)
        {
            //write data to file if user is new 
            string line = username + " " + password;
            
            using (StreamWriter writer = File.AppendText(path))
            {
                writer.WriteLine($"\n{line}");
            }
        }
    }
}
