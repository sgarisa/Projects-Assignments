﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;

namespace PRG282__Project__Group_6_.DataAccess
{
    internal class DataHandler
    {
        string connection = "Data Source=LAPTOP-JVPB6A33\\SQLEXPRESS;Initial Catalog=BCStudentDB;Integrated Security=True";

        SqlDataAdapter da;
        DataTable dt;
        //connect to database and perform management tasks

        //ADO.NET connections and operations, and SQL commands

        public DataTable fetchStudentData()
        {
            string query = "SELECT * FROM Student";

            da = new SqlDataAdapter(query, connection);
            dt = new DataTable();

            da.Fill(dt);
            return dt;
        }

        public DataTable searchStudent(decimal number)
        {
            //select students with a specific search criteria

            string query = $"SELECT * FROM Student WHERE StudentNumber = {number}";
            da = new SqlDataAdapter(query, connection);
            dt = new DataTable();
            da.Fill(dt);    
            return dt;
        }

        
        public void insertStudent(string fn, string sn, string pp, DateTime dob, string g, string p, string r)
        {
            string query = $"INSERT INTO Student VALUES ('{fn}', '{sn}', '{pp}', '{dob}', '{g}', '{p}', '{r}')";

            using (SqlConnection con = new SqlConnection(connection))
            {
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();
                }
            }
        }
        
        public void updateStudent(int studNum, string fn, string sn, string pp, DateTime dob, string g, string p, string r)
        {
            string query = $"UPDATE Student SET Firstname= '{fn}',Surname= '{sn}',ProfilePhoto= '{pp}',DateOfBirth= '{dob}',Gender= '{g}',phone= '{p}',Residence= '{r}' WHERE StudentNumber = {studNum}";
            using (SqlConnection con = new SqlConnection(connection))
            {
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();
                }
            }
        }

        public void deleteStudent(decimal number)
        {
            string query = $"DELETE  FROM Student WHERE StudentNumber = {number}";

            using (SqlConnection con = new SqlConnection(connection))
            {
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();
                }
            }
        }
        
        public DataTable fetchModuleData()
        {
            string query = "SELECT * FROM Module";

            da = new SqlDataAdapter(query, connection);
            dt = new DataTable();

            da.Fill(dt);
            return dt;
        }

        
        public DataTable searchModule(decimal mcode)
        {
            string query = $"SELECT * FROM Module WHERE ModuleCode = {mcode}";
            da = new SqlDataAdapter(query, connection);
            dt = new DataTable();
            da.Fill(dt);    
            return dt;        }

        
        public void insertModule(string mname, string mdescr, string mlink)
        {
            string query = $"INSERT INTO Module VALUES ('{mname}', '{mdescr}', '{mlink}')";

            using (SqlConnection con = new SqlConnection(connection))
            {
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();
                }
            }
        }


        public void updateModule(decimal modCode, string mname, string mdescr, string mlink)
        {
            string query = $"UPDATE Module SET ModuleName= '{mname}',ModDescription= '{mdescr}',Links= '{mlink}' WHERE ModuleCode = {modCode}";
            using (SqlConnection con = new SqlConnection(connection))
            {
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();
                }
            }
        }

        public void deleteModule(decimal mcode)
        {
            string query = $"DELETE  FROM Module WHERE ModuleCode = {mcode}";

            using (SqlConnection con = new SqlConnection(connection))
            {
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    con.Open();
                    cmd.ExecuteNonQuery();
                    con.Close();
                }
            }
        }
    }
}